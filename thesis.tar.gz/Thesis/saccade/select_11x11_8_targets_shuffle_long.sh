#!/bin/bash
# ------------------------------------------------------------------
# [Author] Title
#          Description
# ------------------------------------------------------------------
# rm select_11x11_8_targets_shuffle_long/TrainingSet.txt.results
python model.py select_11x11_8_targets_shuffle_long
