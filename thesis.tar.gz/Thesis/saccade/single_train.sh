#!/bin/bash
# ------------------------------------------------------------------
# [Author] Title
#          Description
# ------------------------------------------------------------------
rm TrainingSetSmall.txt.results
python model.py TrainingSetSmall.txt